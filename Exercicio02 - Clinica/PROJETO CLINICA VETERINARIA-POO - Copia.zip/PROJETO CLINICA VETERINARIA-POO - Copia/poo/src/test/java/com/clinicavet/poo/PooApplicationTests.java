package com.clinicavet.poo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PooApplicationTests {

	@Test
	void contextLoads() {
	}

}
