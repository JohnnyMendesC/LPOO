package com.clinicavet.poo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PooApplication {

	public static void main(String[] args) {
		SpringApplication.run(PooApplication.class, args);

/*classes a serem geradas :
Pessoa: Proprietário , Veterinário ( login e senha ?)
Procedimentos: Vacinas, Consultas, Procedimento Cirurgico.
Clínica veterinária : endereco
Pet



Ter dois menus :  um para o médico e outro para o usuário. 




*/


	}

}
