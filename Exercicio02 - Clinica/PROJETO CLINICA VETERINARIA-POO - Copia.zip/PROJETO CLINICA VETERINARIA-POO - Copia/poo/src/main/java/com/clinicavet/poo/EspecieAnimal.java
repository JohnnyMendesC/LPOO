package com.clinicavet.poo;

public enum EspecieAnimal {
    CACHORRO,
    GATO,
    ROEDOR,
    AVE


}
