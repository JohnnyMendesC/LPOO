package com.clinicavet.poo;

public enum StatusConsulta {
        AGENDADA,
        EM_ANDAMENTO,
        FINALIZADA,
        CANCELADA


}
