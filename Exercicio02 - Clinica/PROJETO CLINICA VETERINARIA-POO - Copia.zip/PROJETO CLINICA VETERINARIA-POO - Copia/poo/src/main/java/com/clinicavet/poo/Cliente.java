package com.clinicavet.poo;

public class Cliente extends Pessoa {

private int idCliente;
private int contadorCliente;
private String dataCadastro;
//login e senha 
//deve consultar os prontuários (historicos de atendimento) de TODOS os pets. 



}
