package com.clinicavet.poo;
// verificar se vai manter essa classe.
public class Procedimento extends Medicovet {

    private String tipoProcedimento; // verificar se haverá : (Consulta , vacina , procedimento cirurgico(castração) )
    private String dataProcedimento;


}
