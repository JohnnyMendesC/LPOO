package com.clinicavet.poo;

public abstract class Animal  {

private String dataNascimento;
private EspecieAnimal especieAnimal; //esse é um enum
private String raca;
private CorPet cor; // esse é um enum.








}
