package com.clinicavet.poo;

public enum CorPet {
    FULVO,
    PRETO,
    BRANCO,
    MARROM,
    CINZA,
    AMARELO,
    CARAMELO,
    MALHADO,
    TRICOLOR,
    BICOLOR
    
}